import mysql.connector
x = mysql.connector.connect(host="localhost", user="root", passwd="prathiksha")
y = x.cursor()
y.execute("CREATE DATABASE APPONIX")


