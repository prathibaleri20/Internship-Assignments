import mysql.connector

x = mysql.connector.connect(host="localhost", user="root", passwd="prathiksha", database="apponix")
y = x.cursor()
query = "SELECT NAME, ROLL FROM STUDENT ORDER BY NAME DESC"
y.execute(query)
myresult = y.fetchall()
for x in myresult:
    print(x)
# disconnecting from server
x.close()