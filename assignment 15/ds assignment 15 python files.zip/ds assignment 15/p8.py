import mysql.connector

x = mysql.connector.connect(host="localhost", user="root", passwd="prathiksha", database="apponix")
y = x.cursor()
query = "UPDATE STUDENT SET AGE = 23 WHERE Name ='Sita'  "
y.execute(query)
myresult = y.fetchall()
for x in myresult:
    print(x)
# disconnecting from server
x.close()