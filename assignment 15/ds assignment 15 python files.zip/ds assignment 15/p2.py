import mysql.connector
x = mysql.connector.connect(host="localhost", user="root", passwd="prathiksha", database="apponix")

y = x.cursor()
studentRecord = """CREATE TABLE STUDENT \
                   ( \
                       NAME    VARCHAR(20) NOT NULL, \
                       BRANCH  VARCHAR(50), \
                       ROLL    INT         NOT NULL, \
                       SECTION VARCHAR(5), \
                       AGE     INT
                   )"""
# table created
y.execute(studentRecord)

# disconnecting from server
x.close()
