import mysql.connector
x = mysql.connector.connect(host="localhost", user="root", passwd="prathiksha", database="apponix")
y = x.cursor()
sql = "INSERT INTO STUDENT values('rakshita','csd',101,'a',23)"
y.execute(sql)
x.commit()
x.close()